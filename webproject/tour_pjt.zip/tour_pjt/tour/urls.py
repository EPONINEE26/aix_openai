from django.urls import path,include
from.import views

app_name='tour'
urlpatterns = [
    path('tour/', views.tour, name='tour'),
    path('tour/tlist/', views.tlist, name='tlist'),
    path('tour/tplace/', views.tplace, name='tplace'),
    path('tour/tstay/', views.tstay, name='tstay'),
    path('tour/tfood/', views.tfood, name='tfood'),

]